#inc\
lude <stdio.h>
#define GETS g\
ets

int main(){
  puts(\
  "hello"\
  );
  // qwert\
yu
  if("world"==GETS()){
    puts("!");
  }
  return 0;
}
