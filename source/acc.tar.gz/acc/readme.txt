# The AWK C Compiler Reference Documentation.

## Introduction
Awk C Compiler (aka AwkCC, ACC) is a small C compiler.
It's so easy to use and you can almost use it anywhere: It only needs an AWK.
It doesn't support all features of ANSI C, but for a basic programmer, it's enough to use.

## Compilation speed
GCC is almost 14 times of ACC for an empty program on a VM.

 T^^^^^^^^^^^^^^^^^^^^^T
 | #include <stdio.h>  |
 |                     |
 | int main(){         |
 |                     |
 |   return 0;         |
 | }                   | 
 |_____________________|

  / GCC 3.80s
 <
  \ ACC 0.27s

## Command line invocation

###  Quick start
Use command `./acc FILENAME.c`
The executable file will be named as `FILENAME.out`
For more options, see "Options".

### More options
Go to "./src/" directory.
You'll find 4 files, which named from 0 to 3.
 @ "0" is code reader.
 @ "1" is the pre-processor.
 @ "2" is the conmpiler.
 @ "3" is the linker.
All of them can be runned by AWK.
If you run some of them, you'll get something more.

## Language support
ACC doesn't support all of the ANSI C Standard.
But You can use these things:
 @ #include
 @ #define (no args)
 @ functions
 @ non-pointer variables and arrays
 @ if-else_if-else statement (no turnary operators or switch)
 @ for and while (no do-while)
 @ break and continue
 @ comments
They can simulate most of features in C.
Also, there is a marco to tell ACC and others: __AwkCC__(is 1)

